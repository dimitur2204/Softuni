﻿
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Guild
{
    public class Guild
    {
        private List<Player> roster;
        private int capacity;
        public Guild(string name, int capacity)
        {
            this.Name = name;
            this.capacity = capacity;
            this.roster = new List<Player>();
        }
        public string Name { get; private set; }
        public int Count => this.roster.Count;

        public void AddPlayer(Player player)
        {
            if (roster.Count == capacity)
            {

            }
            else
            {
                roster.Add(player);
            }
        }

        public bool RemovePlayer(string name)
        {
            if (roster.Exists(x => x.Name == name))
            {
                roster.Remove(roster.Find(x => x.Name == name));
                return true;
            }

            return false;
        }

        public void PromotePlayer(string name)
        {
            roster.First(x => x.Name == name).Rank = "Member";
        }
        public void DemotePlayer(string name)
        {
            roster.First(x => x.Name == name).Rank = "Trial";
        }
        public Player[] KickPlayersByClass(string Class)
        {
            var arr = roster.FindAll(x => x.Class == Class).ToArray();
            roster.RemoveAll(x => x.Class == Class);
            return arr;
        }

        public string Report()
        {
            var report = new StringBuilder();
            report.AppendLine($"Players in the guild: {this.Name}");
            foreach (var player in this.roster)
            {
                report.AppendLine(player.ToString());
            }

            return report.ToString();
        }
   }
}
