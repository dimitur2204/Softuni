﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class DarkKnight : Knight
    {
        public DarkKnight(string name, int level)
            : base(name, level)
        {

        }
    }
}
