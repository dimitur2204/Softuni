﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class DarkWizard : Wizard
    {
        public DarkWizard(string name, int level)
            : base(name, level)
        {
        }
    }
}
