﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Foods
{
    public class Fruit : Food
    {
        public override int Quantity => throw new NotImplementedException();
    }
}
