﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
    interface IElectricCar
    {
        protected int Battery { get; }
    }
}
