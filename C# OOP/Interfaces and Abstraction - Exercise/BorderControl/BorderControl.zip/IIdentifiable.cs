﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IIdentifiable
    {
        public string ID { get; }
    }
}
