﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IBirthable
    {
        public string Name { get; }
        public string Birthdate { get; }
    }
}
