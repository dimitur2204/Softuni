﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface IStationary
    {
        public string Dial(string number);
    }
}
