﻿namespace OnlineShop.Common.Enums
{
    public enum PeripheralType
    {
        Headset = 1,
        Keyboard = 2,
        Monitor = 3,
        Mouse = 4,
    }
}