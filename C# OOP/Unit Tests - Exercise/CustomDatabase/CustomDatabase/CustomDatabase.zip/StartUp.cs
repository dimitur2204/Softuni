﻿
using System;

namespace CustomDatabase
{ 
    using System.Collections.Generic;
class Program
    {
        static void Main(string[] args)
        {
            var arr = new List<int>();
            for (int i = 1; i <= 15; i++)
            {
                arr.Add(i);
            }
            var db = new Database(arr);
            db.Add(5);
            db.Remove(5);
            foreach (var i in db.Fetch())
            {
                Console.WriteLine(i);
            }
        }
    }
}
