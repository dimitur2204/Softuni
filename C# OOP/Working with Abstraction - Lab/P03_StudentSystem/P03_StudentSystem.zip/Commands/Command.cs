﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03StudentSystem
{
    class Command
    {
        public string Name { get; set; }
        public string[] Arguments { get; set; }
    }
}
